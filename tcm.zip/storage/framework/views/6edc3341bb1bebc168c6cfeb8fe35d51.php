<?php

use Livewire\Volt\Component;
use App\Models\Ciclista;
use Illuminate\Support\Facades\Auth;

?>

<div class="p-4 bg-white rounded-lg shadow">
    <h2 class="mb-4 text-lg font-bold">Alineación para la carrera <?php echo e($numCarrera); ?></h2>

    <form wire:submit="mostrarAlineacion">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = range(0, 7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700">Corredor <?php echo e($index + 1); ?></label>
                <select wire:model="alineacion.<?php echo e($index); ?>" class="w-full px-3 py-2 border rounded">
                    <option value="">(Vacío)</option>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $ciclistasDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciclista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ciclista->cod_ciclista); ?>"><?php echo e($ciclista->nom_abrev); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </select>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

        <button type="submit" class="px-4 py-2 mt-4 text-white bg-blue-500 rounded">
            Mostrar Alineación
        </button>

        <!--[if BLOCK]><![endif]--><?php if($mensaje): ?>
            <div class="p-2 mt-4 text-sm text-white bg-green-500 rounded">
                <?php echo e($mensaje); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </form>
</div><?php /**PATH C:\laragon\www\tcm\resources\views\livewire/alineacion.blade.php ENDPATH**/ ?>