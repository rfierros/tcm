<?php

use Livewire\Volt\Component;

new class extends Component {
    //
}; 
// dd($etapa);
?>

<div>
   <h2 class="text-xl text-red-800 bg-green-200">Aqui el show de la etapa</h2>
   {{-- <p>Etapa número {{$etapa->num_etapa}}</p>
   <p>Día {{$etapa->dia}}</p>
   <p>id {{$etapa->id}}</p> --}}
</div>
