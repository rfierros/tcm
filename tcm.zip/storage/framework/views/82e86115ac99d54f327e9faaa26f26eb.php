<?php

use Livewire\Volt\Component;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Collection;
use App\Models\Equipo;

?>

<div class="mt-6 bg-white divide-y rounded-lg shadow-sm">
    <div class="p-10">
        <div x-data="{
            column: 'total_pts',
            order: 'desc',
            sort(column) {
                this.order = (this.column === column && this.order === 'desc') ? 'asc' : 'desc';
                this.column = column;
            },
            sortedEquipos() {
                return [...<?php echo e($equipos); ?>].sort((a, b) => {
                    let modifier = this.order === 'asc' ? 1 : -1;
                    return (a[this.column] < b[this.column] ? -1 : 1) * modifier;
                });
            }
        }">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-xl font-semibold">Clasificación de Equipos</h3>
                <button wire:click="cargarClasificacion" class="px-4 py-2 text-white bg-blue-500 rounded">
                    🔄 Actualizar
                </button>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-300">
                    <thead>
                        
                        <tr class="bg-gray-200">
                            <th class="px-4 py-2 text-left">Pos.</th>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="px-4 py-2 text-left">
                                    <div class="flex items-center cursor-pointer" @click="sort('<?php echo e($field); ?>')">
                                        <span><?php echo e($label); ?></span>
                                        <span class="ml-2 text-gray-500">
                                            <template x-if="column === '<?php echo e($field); ?>' && order === 'desc'">▼</template>
                                            <template x-if="column === '<?php echo e($field); ?>' && order === 'asc'">▲</template>
                                        </span>
                                    </div>
                                </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tr>
                    </thead>
                    <tbody>
                        <template x-for="(equipo, index) in sortedEquipos()" :key="equipo.cod_equipo">
                            <tr class="hover:bg-gray-100">
                                <td class="px-4 py-2" x-text="index + 1"></td>
                                <td class="px-4 py-2" x-text="equipo.nombre_equipo"></td>
                                <td class="px-4 py-2 text-right" x-text="equipo.total_pts.toFixed(4)"></td>
                                <td class="px-4 py-2 text-center" x-text="equipo.num_victorias"></td>
                                <td class="px-4 py-2 text-center" x-text="equipo.etapas_disputadas"></td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\tcm\resources\views\livewire/clasificacion/show.blade.php ENDPATH**/ ?>