<?php

use Livewire\Volt\Component;
use Livewire\Attributes\On; 
use App\Models\Resultado;
use App\Models\Ciclista;
use App\Models\Equipo;
use Illuminate\Database\Eloquent\Collection;

?>

<div class="mt-6 bg-white divide-y rounded-lg shadow-sm"> 

<div class="p-10">
    <div class="flex flex-col">
        <div x-data="{
            equipos: <?php echo e(json_encode($equipos)); ?>,
            column: '',
            order: 'asc',
            selectedFilter: 'WT',  // Valor inicial para mostrar todos los registros
            sort(column, order) {
                this.column = column;
                this.order = order;
            },
            sortedEquipos() {
                let filteredData = [...this.equipos];

                // Aplicar filtros en base al valor de selectedFilter
                if (this.selectedFilter === 'Conti') {
                    filteredData = filteredData.filter(equipo => equipo.conti);
                }

                return filteredData.sort((a, b) => {
                    let modifier = this.order === 'asc' ? 1 : -1;
                    if (a[this.column] < b[this.column]) return -1 * modifier;
                    if (a[this.column] > b[this.column]) return 1 * modifier;
                    return 0;
                });
            },
            formatNumber(value) {
                const [integerPart, decimalPart] = value.toFixed(2).split('.');
                return { integerPart, decimalPart };
            },
            getCategoryColor(cat) {
                const colors = {
                    'wt': 'bg-orange-500/70 font-bold',
                    'conti': 'bg-green-400/70 font-bold',
                };
                return colors[cat.toLowerCase()] || 'bg-white';
            }
        }">
            <div class="flex items-center justify-between mb-4">
                <h3 class="mb-4 text-xl font-semibold leading-tight text-gray-800">
                    Clasificación
                </h3> 

            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-neutral-200">
                    <thead>
                        <tr>
                            <th class="px-2 py-1.5 text-xxs leading-none text-left">Pos.</th>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="px-2 py-1.5 text-xxs leading-none uppercase">
                                    <div class="flex items-center space-x-2">
                                        <span @click="sort('<?php echo e($column); ?>', order === 'asc' ? 'desc' : 'asc')" class="cursor-pointer">
                                            <?php echo e($label); ?>

                                        </span>
                                        <div class="flex flex-col text-gray-400">
                                            <span @click="sort('<?php echo e($column); ?>', 'desc')" class="leading-none cursor-pointer">˄</span>
                                            <span @click="sort('<?php echo e($column); ?>', 'asc')" class="leading-none cursor-pointer">˅</span>
                                        </div>
                                    </div>
                                </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tr>
                    </thead>
                    <tbody>
                        <template x-for="(equipo, index) in sortedEquipos()" :key="equipo.cod_equipo">
                            
                            <tr :class="getCategoryColor(equipo.categoria)"  class="hover:bg-slate-100">
                                <td class="px-2 py-1.5 text-xs" x-text="index + 1"></td>
                                <template x-for="(label, field) in <?php echo e(json_encode($columns)); ?>" :key="field">
                                    <td class="px-2 py-1.5 text-xs">
                                        <template x-if="['total_pts'].includes(field)">
                                            <span>
                                                <span x-text="formatNumber(equipo[field]).integerPart"></span>
                                                <span x-text="'.' + formatNumber(equipo[field]).decimalPart"></span>
                                            </span>
                                        </template>
                                        <template x-if="!['total_pts'].includes(field)">
                                            <span x-text="equipo[field]"></span>
                                        </template>
                                    </td>
                                </template>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


</div><?php /**PATH C:\laragon\www\tcm\resources\views\livewire/clasificacion/list.blade.php ENDPATH**/ ?>