<?php

use Livewire\Volt\Component;
use Livewire\Attributes\On; 
use App\Models\Carrera;
use App\Models\Etapa;
use App\Models\Resultado;
use App\Models\Ciclista;
use App\Models\Equipo;
use Illuminate\Database\Eloquent\Collection;

?>

<div class="mt-6 bg-white divide-y rounded-lg shadow-sm"> 
    <div class="p-10">
        <div x-data="{            
            getColor(perfil) {
                const colors = {
                    'llano': 'bg-green-50 text-green-600 ring-green-500/10',
                    'media-montaña': 'bg-yellow-50 text-yellow-800 ring-yellow-600/20',
                    'montaña': 'bg-red-50 text-red-700 ring-red-600/10',
                };
                return colors[perfil] || 'bg-pink-100 text-pink-600 ring-pink-500/10';
            }
        }">

            <h3 class="mb-4 text-xl font-semibold leading-tight text-gray-800"><?php echo e($carrera->nombre); ?></h3>
            <ul role="list" class="grid grid-cols-1 gap-5 mt-3 sm:grid-cols-2 sm:gap-6 md:grid-cols-3 xl:grid-cols-4">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $etapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etapa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>

                    <a href="<?php echo e(route('etapas', $etapa->slug)); ?>" class="flex items-center justify-between w-full p-2 space-x-3 text-left border border-gray-300 rounded-lg shadow-sm group hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
                    <span class="flex items-center flex-1 min-w-0 space-x-3">
                        <div class="flex-shrink-0">
                            <span x-bind:class="getColor('<?php echo e($etapa->nombre); ?>')" class="inline-flex items-center justify-center w-10 h-10 text-xs rounded-lg">
                                <?php echo e($etapa->num_etapa); ?> 
                            </span>
                        </div>
                    
                        <span class="flex-1 block min-w-0">
                        <span class="block text-sm font-medium text-gray-900 truncate"><?php echo e($etapa->nombre); ?></span>
                        <span class="block text-sm font-medium text-gray-500 truncate"><span x-bind:class="getColor('<?php echo e($etapa->perfil); ?>')" class="inline-flex items-center rounded-md px-1.5 py-0.5 text-xs font-medium ring-1 ring-inset"><?php echo e($etapa->perfil); ?></span> - <?php echo e($etapa->km); ?>km</span>
                        
                        </span>
                    </span>
                    </a>
                </li>                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
  
        </div>
    </div>
    <div class="p-10">
        <div x-data="{            
            formatNumber(value) {
                const [integerPart, decimalPart] = value.toFixed(2).split('.');
                return { integerPart, decimalPart };
            },
            getBadgeColor(especialidad) {
                const colors = {
                    'ardenas': 'bg-pink-600/30 text-pink-600',
                    'flandes': 'bg-yellow-400/30 text-yellow-500',
                    'sprinter': 'bg-green-500/30 text-green-600',
                    'escalador': 'bg-yellow-800/30 text-yellow-800',
                    'combatividad': 'bg-purple-800/30 text-purple-800',
                    'croner': 'bg-cyan-400/30 text-cyan-600',
                };
                return colors[especialidad.toLowerCase()] || 'bg-gray-500 text-white';
            }            
        }">

            <h3 class="mb-4 text-xl font-semibold leading-tight text-gray-800">Inscripciones</h3>
            <ul role="list" class="grid grid-cols-1 gap-5 mt-3 sm:grid-cols-2 sm:gap-6 md:grid-cols-3 xl:grid-cols-4">

                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $ciclistas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciclista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div class="flex items-center justify-between w-full p-2 space-x-3 text-left border border-gray-300 rounded-lg shadow-sm group hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
                    <span class="flex items-center flex-1 min-w-0 space-x-3">
                        <span class="flex-1 block min-w-0">
                            <span class="block text-sm font-medium text-gray-900 truncate"><?php echo e($ciclista->nom_abrev); ?></span>
                            <span class="block text-sm font-medium text-gray-500 truncate"><span x-bind:class="getBadgeColor('<?php echo e($ciclista->especialidad); ?>')" class="inline-flex items-center rounded-md px-1.5 py-0.5 text-xs font-medium"><?php echo e($ciclista->especialidad); ?></span> - <?php echo e($ciclista->media); ?></span>
                        </span>
                    </span>
                    </div>
                </li>      
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
        
        </div>
    </div>


    <div class="p-10">
        <div x-data="{            
            formatNumber(value) {
                const [integerPart, decimalPart] = value.toFixed(2).split('.');
                return { integerPart, decimalPart };
            },
            getBadgeColor(especialidad) {
                const colors = {
                    'ardenas': 'bg-pink-600/30 text-pink-600',
                    'flandes': 'bg-yellow-400/30 text-yellow-500',
                    'sprinter': 'bg-green-500/30 text-green-600',
                    'escalador': 'bg-yellow-800/30 text-yellow-800',
                    'combatividad': 'bg-purple-800/30 text-purple-800',
                    'croner': 'bg-cyan-400/30 text-cyan-600',
                };
                return colors[especialidad.toLowerCase()] || 'bg-gray-500 text-white';
            }            
        }">

            <h3 class="mb-4 text-xl font-semibold leading-tight text-gray-800">Inscripciones</h3>
            <ul role="list" class="grid grid-cols-1 gap-5 mt-3 sm:grid-cols-2 sm:gap-6 md:grid-cols-3 xl:grid-cols-4">

        
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $allCiclistas->groupBy('equipo.nombre_equipo'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipoNombre => $ciclistas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-8 team-group ">
                    <h3 class="mb-4 font-semibold leading-tight text-gray-800"><?php echo e($equipoNombre ?? 'Sin equipo'); ?></h3>
                    <ul>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $ciclistas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciclista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <!--[if BLOCK]><![endif]--><?php if($ciclista->hasTiempoD): ?>
                                <div class="flex items-center justify-between w-full p-2 space-x-3 text-left bg-red-300 border border-gray-300 rounded-lg shadow-sm group hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
                                <?php else: ?>
                                <div class="flex items-center justify-between w-full p-2 space-x-3 text-left border border-gray-300 rounded-lg shadow-sm group hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <span class="flex items-center flex-1 min-w-0 space-x-3">
                                    <span class="flex-1 block min-w-0">
                                        <span class="block text-sm font-medium text-gray-900 truncate"><?php echo e($ciclista->nom_abrev); ?></span>
                                        <span class="block text-sm font-medium text-gray-500 truncate"><span x-bind:class="getBadgeColor('<?php echo e($ciclista->especialidad); ?>')" class="inline-flex items-center rounded-md px-1.5 py-0.5 text-xs font-medium"><?php echo e($ciclista->especialidad); ?></span> - <?php echo e($ciclista->media); ?></span>
                                    </span>
                                </span>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </ul>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

            </ul>
        
        </div>
    </div>



</div><?php /**PATH C:\laragon\www\tcm\resources\views\livewire/etapas/list.blade.php ENDPATH**/ ?>