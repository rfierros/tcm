///  INSCRIPCIONES MAL POR INSCRIBIR EN UNA U24 A UN CORREDOR NO U24
SELECT 
    c.cod_ciclista AS id, 
    c.nom_ape, 
    c.edad, 
    c.media, 
    e.nombre_equipo, 
    r.num_carrera
FROM ciclistas c
JOIN resultados r 
    ON c.cod_ciclista = r.cod_ciclista -- Cambiado c.id por c.cod_ciclista
JOIN carreras ca 
    ON r.num_carrera = ca.num_carrera 
    AND r.temporada = ca.temporada -- Aseguramos la relación correcta
JOIN equipos e 
    ON c.cod_equipo = e.cod_equipo -- Cambiado e.id por e.cod_equipo
WHERE ca.categoria = 'U24'
  AND (c.edad > 24 OR c.media >= 75);


///  INSCRIPCIONES MAL POR SER CONTI Y EL CORREDOR TENER A PARTIR DE 78 EN ALGUNA ESTADISTICA
SELECT 
    c.cod_ciclista AS id, 
    c.nom_ape, 
    e.nombre_equipo, 
    r.num_carrera, 
    r.cod_ciclista
FROM ciclistas c
JOIN resultados r 
    ON c.cod_ciclista = r.cod_ciclista -- Cambiado c.id por c.cod_ciclista
JOIN carreras ca 
    ON r.num_carrera = ca.num_carrera 
    AND r.temporada = ca.temporada -- Aseguramos la relación correcta
JOIN equipos e 
    ON c.cod_equipo = e.cod_equipo -- Cambiado e.id por e.cod_equipo
WHERE ca.categoria = 'Conti'
  AND (
    c.lla >= 78 OR
    c.mon >= 78 OR
    c.col >= 78 OR
    c.cri >= 78 OR
    c.pro >= 78 OR
    c.pav >= 78 OR
    c.spr >= 78 OR
    c.acc >= 78 OR
    c.des >= 78 OR
    c.com >= 78 OR
    c.ene >= 78 OR
    c.res >= 78 OR
    c.rec >= 78
  );


///  INSCRIPCIONES MAL POR HACERSE EN FECHAS COINCIDENTES
SELECT 
    r1.cod_ciclista,
    c.nom_ape AS nombre_ciclista,
    eq.nombre_equipo AS equipo,
    c1.nombre AS carrera1,
    c2.nombre AS carrera2,
    e1.dia AS fecha_coincidente
FROM resultados r1
JOIN resultados r2 
    ON r1.cod_ciclista = r2.cod_ciclista
    AND (r1.num_carrera != r2.num_carrera OR r1.temporada != r2.temporada)
    AND (r1.num_carrera < r2.num_carrera OR (r1.num_carrera = r2.num_carrera AND r1.temporada < r2.temporada)) -- Evitar duplicados
JOIN etapas e1 
    ON e1.num_carrera = r1.num_carrera
    AND e1.temporada = r1.temporada
    AND e1.num_etapa = r1.etapa
JOIN etapas e2 
    ON e2.num_carrera = r2.num_carrera
    AND e2.temporada = r2.temporada
    AND e2.num_etapa = r2.etapa
    AND e1.dia = e2.dia -- Coincidencia en el día de la etapa
JOIN carreras c1 
    ON c1.num_carrera = r1.num_carrera
    AND c1.temporada = r1.temporada
JOIN carreras c2 
    ON c2.num_carrera = r2.num_carrera
    AND c2.temporada = r2.temporada
JOIN ciclistas c
    ON c.cod_ciclista = r1.cod_ciclista -- Cambiado ciclista_id por cod_ciclista
JOIN equipos eq
    ON eq.cod_equipo = c.cod_equipo -- Asegurarnos de usar el campo correcto para equipos
WHERE r1.cod_ciclista IS NOT NULL
GROUP BY 
    r1.cod_ciclista, c.nom_ape, eq.nombre_equipo, c1.nombre, c2.nombre, e1.dia
ORDER BY e1.dia DESC, eq.nombre_equipo, r1.cod_ciclista, e1.dia

///  Query obligacion de equipo WT de inscribir en WT
///  Query obligacion de equipo conti de inscribir en una .1
///  Query no repetir CORREDOR en una misma carrera
///  Query no tener el numero correcto de corredores (la misma si ponemos "y distinct")

// puntos sumados por cada equipo en unas carreras determinadas (semana).
SELECT 
    e.nombre_equipo AS equipo,
    r.cod_equipo,
    SUM(r.pts) AS raw_pts,
    printf('%.4f', SUM(r.pts)) AS total_pts
FROM 
    resultados r
JOIN 
    equipos e ON r.cod_equipo = e.cod_equipo
WHERE 
    r.num_carrera IN (40, 41, 42, 43)
GROUP BY 
    r.cod_equipo, e.nombre_equipo
ORDER BY 
    SUM(r.pts) DESC
    
// Suma de puntos de los corredores de un equipo para una carrera determinada
SELECT 
    r.cod_ciclista,
    c.nom_ape AS nombre_ciclista,
    SUM(r.pts) AS total_pts_raw, -- Mantener el valor numérico original para el orden
    printf('%.4f', SUM(r.pts)) AS total_pts -- Formatear para mostrar
FROM 
    resultados r
JOIN 
    ciclistas c ON r.cod_ciclista = c.cod_ciclista
WHERE 
    r.cod_equipo = 33
GROUP BY 
    r.cod_ciclista, c.nom_ape
ORDER BY 
    total_pts_raw DESC

// Dias corridos por equipo
SELECT 
    e.nombre_equipo AS equipo,
    r.cod_equipo,
    COUNT(r.id) AS dias_corridos
FROM 
    resultados r
JOIN 
    equipos e ON r.cod_equipo = e.cod_equipo
WHERE 
    r.num_carrera BETWEEN 1 AND 70
GROUP BY 
    r.cod_equipo, e.nombre_equipo
ORDER BY 
    dias_corridos DESC

// Query para comparar los puntos conseguidos entre distintos corredores (p.ej. Draft)
SELECT 
    r.cod_ciclista,
    c.nom_ape AS nombre_ciclista,
    e.nombre_equipo AS equipo,
    SUM(r.pts) AS total_pts_raw,  -- Valor original para ordenación
    printf('%.4f', SUM(r.pts)) AS total_pts  -- Formateado para mostrar
FROM 
    resultados r
JOIN 
    ciclistas c ON r.cod_ciclista = c.cod_ciclista
JOIN 
    equipos e ON c.cod_equipo = e.cod_equipo
WHERE 
    r.cod_ciclista IN (1939, 10503, 7040)
GROUP BY 
    r.cod_ciclista, c.nom_ape, e.nombre_equipo
ORDER BY 
    total_pts_raw DESC;

// Query para comparar los puntos conseguidos entre distintos corredores (p.ej. Draft) POR EQUIPO
SELECT 
    e.nombre_equipo AS equipo,
    SUM(r.pts) AS total_pts_raw,  -- Valor original para ordenación
    printf('%.4f', SUM(r.pts)) AS total_pts  -- Formateado para mostrar
FROM 
    resultados r
JOIN 
    ciclistas c ON r.cod_ciclista = c.cod_ciclista
JOIN 
    equipos e ON c.cod_equipo = e.cod_equipo
WHERE 
    r.cod_ciclista IN (1939, 10503, 7040)
GROUP BY 
    e.nombre_equipo
ORDER BY 
    total_pts_raw DESC;

/***************************************
  IMPLEMENTAR ESTAS 
***************************************/

-Comprobar que todos los equipos WT están inscritos en la carrera WT
-Comprobar que todos los equipos Conti están inscritos en la carrera Conti
-Detectar las CRE para meter 5 espectadores en la start list
-publicar en portada la clasificacion general.
