<?php

use Livewire\Volt\Component;
use App\Models\Ciclista;

?>

<div>
    <button wire:click="$refresh" class="px-4 py-2 mb-2 text-white bg-blue-500 rounded">
        Actualizar
    </button>

    <!--[if BLOCK]><![endif]--><?php if($this->ciclistas()->isNotEmpty()): ?>
        <table class="w-full border border-collapse border-gray-300">
            <thead>
                <tr class="bg-gray-200">
                    <th class="px-4 py-2 border">Nombre</th>
                    <th class="px-4 py-2 border">Equipo</th>
                    <th class="px-4 py-2 border">Puntos</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->ciclistas(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciclista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-4 py-2 border"><?php echo e($ciclista->nom_abrev); ?></td>
                        <td class="px-4 py-2 border"><?php echo e($ciclista->equipo->nombre_equipo ?? 'Sin equipo'); ?></td>
                        <td class="px-4 py-2 border"><?php echo e(number_format($ciclista->resultados_sum_pts, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-center text-gray-500">No hay ciclistas para mostrar.</p>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH C:\laragon\www\tcm\resources\views\livewire/tabla-ciclistas.blade.php ENDPATH**/ ?>