<?php

use Livewire\Volt\Component;
use Livewire\Attributes\On; 
use App\Models\Carrera;
use Illuminate\Database\Eloquent\Collection;

?>

<div class="mt-6 bg-white divide-y rounded-lg shadow-sm"> 
    <div class="p-10">
        <div x-data="{            
            getColor(categoria) {
                const colors = {
                    'WT': 'bg-sky-600/30 text-sky-600',
                    'Conti': 'bg-amber-400/30 text-amber-500',
                    'U24': 'bg-stone-500/30 text-stone-600',
                };
                return colors[categoria] || 'bg-gray-500 text-white';
            }
        }">

            <h3 class="mb-4 text-xl font-semibold leading-tight text-gray-800">Carreras</h3>
            <div class="flex space-x-4">
                    <fieldset aria-label="Choose a filter option">
                        <div class="grid grid-cols-3 gap-3 mt-2 mb-1 sm:grid-cols-6">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $botones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boton => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label :class="{
                                    'bg-indigo-600 text-white hover:bg-indigo-500 ring-0': selectedFilter === '<?php echo e($boton); ?>',
                                    'ring-1 ring-gray-300 bg-white text-gray-900 hover:bg-gray-50': selectedFilter !== '<?php echo e($boton); ?>'
                                }" class="flex items-center justify-center px-3 py-3 text-sm font-semibold uppercase rounded-md cursor-pointer focus:outline-none sm:flex-1">
                                    <input type="radio" name="filter-option" value="<?php echo e($boton); ?>" class="sr-only" @click="selectedFilter = '<?php echo e($boton); ?>'">
                                    <span><?php echo e($label); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->



                        </div>
                    </fieldset>
            </div>
                                
            <ul role="list" class="grid grid-cols-1 gap-5 mt-3 sm:grid-cols-2 sm:gap-6 md:grid-cols-3 xl:grid-cols-4">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(route('etapas', $carrera->slug)); ?>" class="flex items-center justify-between w-full p-2 space-x-3 text-left border border-gray-300 rounded-lg shadow-sm group hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
                    <span class="flex items-center flex-1 min-w-0 space-x-3">
                        <div class="flex-shrink-0">
                            <span x-bind:class="getColor('<?php echo e($carrera->categoria); ?>')" class="inline-flex items-center justify-center w-10 h-10 text-xs rounded-lg">
                                <?php echo e($carrera->categoria); ?>

                            </span>
                        </div>
                    
                        <span class="flex-1 block min-w-0">
                        <span class="block text-sm font-medium text-gray-900 truncate"><?php echo e($carrera->num_carrera); ?>. <?php echo e($carrera->nombre); ?></span>
                        <span class="block text-sm font-medium text-gray-500 truncate"><?php echo e($carrera->tipo); ?> <?php echo e($carrera->num_etapas > 1 ? '- ' . $carrera->num_etapas . ' etapas' : ''); ?></span>
                        </span>
                    </span>
                    </a>
                </li>                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </ul>

        </div>
    </div>
</div><?php /**PATH C:\laragon\www\tcm\resources\views\livewire/carreras/list.blade.php ENDPATH**/ ?>