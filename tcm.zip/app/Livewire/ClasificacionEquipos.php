<?php

namespace App\Livewire;

use Livewire\Component;

class ClasificacionEquipos extends Component
{
    public function render()
    {
        return view('livewire.clasificacion-equipos');
    }
}
