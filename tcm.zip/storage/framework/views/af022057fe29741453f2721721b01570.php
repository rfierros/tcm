<?php

use Livewire\Volt\Component;
use Livewire\Attributes\On;
use App\Models\Calendario;
use App\Models\Carrera;

?>

<div class="flex flex-col h-full">
    <!-- Encabezado con controles de navegación -->
    <header class="flex items-center justify-between px-6 py-4 border-b border-gray-200">
        <h1 class="text-base font-semibold text-gray-900">
            <time datetime="2024-11">Días de competición</time>
        </h1>
        <div class="flex items-center"> 
            <div class="relative flex items-center bg-white rounded-md shadow-sm">
                <button type="button" class="flex items-center justify-center w-12 text-gray-400 border-l border-gray-300 h-9 rounded-l-md border-y hover:text-gray-500 focus:relative">
                    <span class="sr-only">Semana Anterior</span>
                    <svg class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor"><path d="M11.78 5.22a.75.75 0 0 1 0 1.06L8.06 10l3.72 3.72a.75.75 0 1 1-1.06 1.06l-4.25-4.25a.75.75 0 0 1 0-1.06l4.25-4.25a.75.75 0 0 1 1.06 0Z" /></svg>
                </button>
                <button type="button" class="border-y border-gray-300 px-3.5 text-sm font-semibold text-gray-900 hover:bg-gray-50">Hoy</button>
                <button type="button" class="flex items-center justify-center w-12 text-gray-400 border-r border-gray-300 h-9 rounded-r-md border-y hover:text-gray-500 focus:relative">
                    <span class="sr-only">Semana Siguiente</span>
                    <svg class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor"><path d="M8.22 5.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.75.75 0 0 1-1.06-1.06L11.94 10 8.22 6.28a.75.75 0 0 1 0-1.06Z" /></svg>
                </button>
            </div>
        </div>
    </header>






    <!-- Estructura del calendario principal -->
    <div class="flex flex-col overflow-auto bg-white">
        <!-- Cabecera de los días de la semana -->
        

        <!-- Contenedor de eventos estructurados en filas -->
        <div class="grid grid-rows-1 gap-y-2">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php
                        // Determinamos el día de inicio y la duración en días
                        $diaInicio = $carrera['dia_inicio'];
                        $duracion = $carrera['num_etapas'] ?? 1; // Duración en días, ejemplo de 1 día si no se especifica
                        $colEnd = $diaInicio + $duracion - 1; // Día de fin basado en la duración
                    ?>
                    <div class="grid grid-cols-7 gap-1">
                        <!-- Espacio vacío hasta el día de inicio del evento -->
                        <!--[if BLOCK]><![endif]--><?php for($i = 1; $i < $diaInicio; $i++): ?>
                            <div></div>
                        <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->

                        <!-- Carrera con clase de color dinámica según categoría y tipo -->
                        <div class="col-span-<?php echo e($duracion); ?> p-4 m-1 rounded-lg text-xs font-semibold <?php echo e($carrera['colorClass']); ?>">
                            <?php echo e($carrera['nombre']); ?> (<?php echo e($carrera['num_etapas']); ?>)
                        </div>                        

                        <!-- Espacio vacío después del evento, si corresponde -->
                        <!--[if BLOCK]><![endif]--><?php for($i = $colEnd + 1; $i <= 7; $i++): ?>
                            <div></div>
                        <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>







</div><?php /**PATH C:\laragon\www\tcm\resources\views\livewire/calendarios/list.blade.php ENDPATH**/ ?>